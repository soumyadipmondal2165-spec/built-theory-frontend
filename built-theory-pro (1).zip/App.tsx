import React, { useState, useEffect } from 'react';
import { initializeApp } from "firebase/app";
import { getAuth, signInWithPopup, GoogleAuthProvider, onAuthStateChanged, signOut } from "firebase/auth";
import Header from './components/Header';
import Hero from './components/Hero';
import ToolGrid from './components/ToolGrid';
import Workspace from './components/Workspace';
import { TOOLS } from './constants';
import { Tool, User } from './types';

// Firebase Config
const firebaseConfig = {
  apiKey: "AIzaSyAZvTrFE81bYQ2R7JxQZnV3x6tmh_j6yL0",
  authDomain: "built-theory-auth-439a4.firebaseapp.com",
  projectId: "built-theory-auth-439a4",
  storageBucket: "built-theory-auth-439a4.firebasestorage.app",
  messagingSenderId: "621216043890",
  appId: "1:621216043890:web:8446c3344595abc38e43eb",
  measurementId: "G-MRJEYBFVGZ"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();

// Razorpay Config
const RZP_KEY = "rzp_live_SDvXBbpBeVUe5U";
declare var Razorpay: any;

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [activeTool, setActiveTool] = useState<Tool | null>(null);
  const [showPricing, setShowPricing] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (currentUser) {
        setUser({
            uid: currentUser.uid,
            email: currentUser.email || '',
            photoURL: currentUser.photoURL || '',
            isPremium: localStorage.getItem('isPremium') === 'true' // Persist premium status locally for demo
        });
      } else {
        setUser(null);
      }
    });
    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    try {
        await signInWithPopup(auth, provider);
    } catch (error) {
        console.error("Login failed", error);
    }
  };

  const handleLogout = async () => {
      await signOut(auth);
      localStorage.removeItem('isPremium');
  };

  const handlePayment = (amount: number, planName: string) => {
      if (!user) {
          handleLogin();
          return;
      }

      const options = {
          key: RZP_KEY,
          amount: amount * 100, // Amount in paise
          currency: "INR",
          name: "Built-Theory PRO",
          description: `Subscription - ${planName}`,
          handler: function (response: any) {
              // Payment Success
              alert("Payment Successful! You are now a PRO member.");
              localStorage.setItem('isPremium', 'true');
              setUser(prev => prev ? ({ ...prev, isPremium: true }) : null);
              setShowPricing(false);
          },
          prefill: {
              email: user.email,
          },
          theme: {
              color: "#e33b2f"
          }
      };
      
      const rzp1 = new Razorpay(options);
      rzp1.open();
  };

  const handleJoinPro = () => {
      setShowPricing(true);
  };

  const handleSelectTool = (tool: Tool) => {
    if (tool.isPro && !user?.isPremium) {
        if(window.confirm(`${tool.title} is a PRO feature.\nUpgrade to access?`)) {
            handleJoinPro();
        }
        return;
    }
    setActiveTool(tool);
  };

  const scrollToTools = () => {
    document.getElementById('tools')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#fbfbfd] text-dark font-sans relative">
      <Header 
        user={user} 
        onLogin={handleLogin} 
        onLogout={handleLogout} 
        onJoinPro={handleJoinPro} 
        scrollToTools={scrollToTools}
      />
      
      <main>
        <Hero onExplore={scrollToTools} onJoinPro={handleJoinPro} />
        <ToolGrid tools={TOOLS} onSelectTool={handleSelectTool} />
      </main>

      {activeTool && (
        <Workspace 
            tool={activeTool} 
            user={user}
            onClose={() => setActiveTool(null)} 
            onJoinPro={handleJoinPro}
        />
      )}

      {/* Pricing Modal */}
      {showPricing && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center bg-gray-900/80 backdrop-blur-sm p-4 animate-[fadeIn_0.2s_ease-out]">
              <div className="bg-white rounded-3xl w-full max-w-4xl shadow-2xl overflow-hidden relative">
                  <button onClick={() => setShowPricing(false)} className="absolute top-4 right-4 w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-500">
                      <i className="fas fa-times"></i>
                  </button>
                  <div className="text-center p-8 bg-gray-50 border-b border-gray-100">
                      <h2 className="text-3xl font-bold text-dark mb-2">Upgrade to <span className="text-primary">PRO</span></h2>
                      <p className="text-gray-500">Unlock 10GB limits, premium tools, and unlimited access.</p>
                  </div>
                  <div className="p-8 grid grid-cols-1 md:grid-cols-3 gap-6">
                      {/* Weekly */}
                      <div className="border rounded-2xl p-6 text-center hover:shadow-lg transition-all hover:border-primary cursor-pointer" onClick={() => handlePayment(59, "Weekly")}>
                          <h3 className="font-bold text-gray-500 uppercase text-sm mb-2">Weekly</h3>
                          <div className="text-3xl font-bold text-dark mb-4">₹59<span className="text-sm font-normal text-gray-400">/week</span></div>
                          <ul className="text-left text-sm text-gray-600 space-y-2 mb-6">
                              <li><i className="fas fa-check text-green-500 mr-2"></i> 10GB File Limit</li>
                              <li><i className="fas fa-check text-green-500 mr-2"></i> All Pro Tools</li>
                              <li><i className="fas fa-check text-green-500 mr-2"></i> Priority Processing</li>
                          </ul>
                          <button className="w-full bg-gray-900 text-white py-2 rounded-lg font-bold hover:bg-primary transition-colors">Choose Weekly</button>
                      </div>
                       {/* Monthly */}
                       <div className="border-2 border-primary rounded-2xl p-6 text-center shadow-xl relative transform scale-105 bg-white" onClick={() => handlePayment(199, "Monthly")}>
                          <div className="absolute top-0 left-1/2 -translate-x-1/2 bg-primary text-white text-xs font-bold px-3 py-1 rounded-b-lg">MOST POPULAR</div>
                          <h3 className="font-bold text-primary uppercase text-sm mb-2 mt-2">Monthly</h3>
                          <div className="text-4xl font-bold text-dark mb-4">₹199<span className="text-sm font-normal text-gray-400">/mo</span></div>
                          <ul className="text-left text-sm text-gray-600 space-y-2 mb-6">
                              <li><i className="fas fa-check text-green-500 mr-2"></i> 10GB File Limit</li>
                              <li><i className="fas fa-check text-green-500 mr-2"></i> All Pro Tools</li>
                              <li><i className="fas fa-check text-green-500 mr-2"></i> Priority Processing</li>
                              <li><i className="fas fa-check text-green-500 mr-2"></i> Cancel Anytime</li>
                          </ul>
                          <button className="w-full bg-primary text-white py-3 rounded-lg font-bold shadow-lg hover:bg-red-600 transition-colors">Choose Monthly</button>
                      </div>
                       {/* Yearly */}
                       <div className="border rounded-2xl p-6 text-center hover:shadow-lg transition-all hover:border-primary cursor-pointer" onClick={() => handlePayment(1999, "Yearly")}>
                          <h3 className="font-bold text-gray-500 uppercase text-sm mb-2">Yearly</h3>
                          <div className="text-3xl font-bold text-dark mb-4">₹1999<span className="text-sm font-normal text-gray-400">/year</span></div>
                          <ul className="text-left text-sm text-gray-600 space-y-2 mb-6">
                              <li><i className="fas fa-check text-green-500 mr-2"></i> 10GB File Limit</li>
                              <li><i className="fas fa-check text-green-500 mr-2"></i> All Pro Tools</li>
                              <li><i className="fas fa-check text-green-500 mr-2"></i> Best Value</li>
                          </ul>
                          <button className="w-full bg-gray-900 text-white py-2 rounded-lg font-bold hover:bg-primary transition-colors">Choose Yearly</button>
                      </div>
                  </div>
              </div>
          </div>
      )}

      <footer className="bg-white border-t border-gray-200 py-12 mt-12">
        <div className="max-w-7xl mx-auto px-6 text-center">
            <p className="text-primary font-bold text-lg mb-2">Built-Theory PRO</p>
            <p className="text-gray-400 text-sm">&copy; {new Date().getFullYear()} All Engineering Tools Reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default App;