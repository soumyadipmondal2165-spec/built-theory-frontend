import React, { useState, useRef, useEffect } from 'react';
import { Tool, User } from '../types';
import { processTool } from '../services/apiService';

interface WorkspaceProps {
  tool: Tool;
  user: User | null;
  onClose: () => void;
  onJoinPro: () => void;
}

const Workspace: React.FC<WorkspaceProps> = ({ tool, user, onClose, onJoinPro }) => {
  const [files, setFiles] = useState<File[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [step, setStep] = useState<'upload' | 'config' | 'processing' | 'done'>('upload');
  const [options, setOptions] = useState<Record<string, any>>({});
  
  // Progress States
  const [uploadProgress, setUploadProgress] = useState(0);
  const [processingProgress, setProcessingProgress] = useState(0);

  // Specific state for signature
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);

  // Specific state for organize/rotate (mock pages)
  const [mockPages, setMockPages] = useState<{id: number, rot: number}[]>([
    {id: 1, rot: 0}, {id: 2, rot: 0}, {id: 3, rot: 0}, {id: 4, rot: 0}
  ]);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const FILE_SIZE_LIMIT_FREE = 50 * 1024 * 1024; // 50MB
  const FILE_SIZE_LIMIT_PRO = 10 * 1024 * 1024 * 1024; // 10GB

  // Initialize defaults
  useEffect(() => {
    setFiles([]);
    setOptions({});
    setMockPages([{id: 1, rot: 0}, {id: 2, rot: 0}, {id: 3, rot: 0}, {id: 4, rot: 0}]);
    setUploadProgress(0);
    setProcessingProgress(0);
    
    // Tools that don't need initial file upload
    if (['ppt_gen', 'html2pdf'].includes(tool.id)) {
      setStep('config');
    } else {
      setStep('upload');
    }
  }, [tool]);

  // Determine accepted file types based on tool ID
  const getAcceptType = () => {
    switch (tool.id) {
        case 'word2pdf':
            return ".doc,.docx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        case 'excel2pdf':
            return ".xls,.xlsx,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        case 'ppt2pdf':
            return ".ppt,.pptx,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation";
        case 'img2pdf':
        case 'scan':
            return "image/*,.jpg,.jpeg,.png";
        case 'ppt_gen':
        case 'html2pdf':
            return "*/*"; 
        default:
            // Default to PDF for all other tools (Merge, Split, Compress, PDF to X, etc.)
            return ".pdf,application/pdf";
    }
  };

  // Check limits for Topic to PPT
  const checkTopicLimit = () => {
      if (user?.isPremium) return true;
      if (tool.id !== 'ppt_gen') return true;

      const usageStr = localStorage.getItem('ppt_usage');
      const now = new Date();
      const currentMonth = `${now.getFullYear()}-${now.getMonth()}`;
      
      let usage = { month: currentMonth, count: 0 };
      if (usageStr) {
          try {
             const parsed = JSON.parse(usageStr);
             if (parsed.month === currentMonth) {
                 usage = parsed;
             }
          } catch(e) {}
      }

      if (usage.count >= 5) {
          return false;
      }
      return true;
  };

  const incrementTopicLimit = () => {
      if (user?.isPremium) return;
      if (tool.id !== 'ppt_gen') return;

      const now = new Date();
      const currentMonth = `${now.getFullYear()}-${now.getMonth()}`;
      let usage = { month: currentMonth, count: 0 };
      const usageStr = localStorage.getItem('ppt_usage');
      if (usageStr) {
           try {
             const parsed = JSON.parse(usageStr);
             if (parsed.month === currentMonth) {
                 usage = parsed;
             }
          } catch(e) {}
      }
      usage.count += 1;
      localStorage.setItem('ppt_usage', JSON.stringify(usage));
  };

  // Signature Canvas Logic
  useEffect(() => {
    if (tool.id === 'sign' && step === 'config') {
       const canvas = canvasRef.current;
       if (canvas) {
           const ctx = canvas.getContext('2d');
           if (ctx) {
               ctx.strokeStyle = '#000000';
               ctx.lineWidth = 2;
               ctx.lineCap = 'round';
           }
       }
    }
  }, [tool.id, step]);

  const startDrawing = (e: React.MouseEvent) => {
      setIsDrawing(true);
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext('2d');
      if (ctx && canvas) {
          const rect = canvas.getBoundingClientRect();
          ctx.beginPath();
          ctx.moveTo(e.clientX - rect.left, e.clientY - rect.top);
      }
  };
  const draw = (e: React.MouseEvent) => {
      if (!isDrawing) return;
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext('2d');
      if (ctx && canvas) {
          const rect = canvas.getBoundingClientRect();
          ctx.lineTo(e.clientX - rect.left, e.clientY - rect.top);
          ctx.stroke();
      }
  };
  const stopDrawing = () => setIsDrawing(false);
  const clearSignature = () => {
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext('2d');
      if (ctx && canvas) {
          ctx.clearRect(0, 0, canvas.width, canvas.height);
      }
  };

  // Upload Simulation
  const simulateUpload = (newFiles: File[]) => {
      setUploadProgress(1);
      let progress = 1;
      const interval = setInterval(() => {
          if (progress >= 100) {
              clearInterval(interval);
              setUploadProgress(100);
              
              // Add files after visual upload completes
              setFiles((prevFiles) => [...prevFiles, ...newFiles]);
              
              // Slight delay before navigation to show 100%
              setTimeout(() => {
                  setUploadProgress(0);
                  // Auto-advance if not compare tool (which needs 2 files)
                  if (tool.id !== 'compare') {
                       setStep('config'); 
                  }
              }, 300);
          } else {
              progress += 10;
              setUploadProgress(progress);
          }
      }, 50);
  };

  const validateFiles = (filesToCheck: File[]) => {
      const limit = user?.isPremium ? FILE_SIZE_LIMIT_PRO : FILE_SIZE_LIMIT_FREE;
      const limitLabel = user?.isPremium ? '10GB' : '50MB';

      for (const f of filesToCheck) {
          if (f.size > limit) {
              if (window.confirm(`File ${f.name} exceeds the ${limitLabel} limit.\n${!user?.isPremium ? 'Upgrade to Pro for 10GB limits?' : ''}`)) {
                  if (!user?.isPremium) onJoinPro();
              }
              return false;
          }
      }
      return true;
  };

  // Drag and Drop
  const handleDragOver = (e: React.DragEvent) => { e.preventDefault(); setIsDragging(true); };
  const handleDragLeave = () => setIsDragging(false);
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const droppedFiles = Array.from(e.dataTransfer.files);
      
      // Limit check
      if (tool.id === 'merge' && !user?.isPremium && (files.length + droppedFiles.length) > 10) {
        if(window.confirm("Free limit reached: Max 10 files for Merge.\nUpgrade to Pro for unlimited merging?")) {
            onJoinPro();
        }
        return;
      }

      if (!validateFiles(droppedFiles)) return;

      if (tool.id === 'compare') {
          setFiles((prev) => [...prev, ...droppedFiles]);
      } else {
          if (step === 'upload') {
            simulateUpload(droppedFiles);
          } else {
            setFiles((prev) => [...prev, ...droppedFiles]);
          }
      }
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const selectedFiles = Array.from(e.target.files);

      // Limit check
      if (tool.id === 'merge' && !user?.isPremium && (files.length + selectedFiles.length) > 10) {
        if(window.confirm("Free limit reached: Max 10 files for Merge.\nUpgrade to Pro for unlimited merging?")) {
            onJoinPro();
        }
        e.target.value = '';
        return;
      }

      if (!validateFiles(selectedFiles)) {
          e.target.value = '';
          return;
      }

      if (tool.id === 'compare') {
           setFiles((prev) => [...prev, ...selectedFiles]);
      } else {
           if (step === 'upload') {
               simulateUpload(selectedFiles);
           } else {
               setFiles((prev) => [...prev, ...selectedFiles]);
           }
      }
    }
    e.target.value = '';
  };

  const executeProcess = async () => {
    if (tool.id === 'ppt_gen' && !checkTopicLimit()) {
        if(window.confirm("You have reached your free monthly limit (5 PPTs).\nUpgrade to Pro for unlimited access?")) {
            onJoinPro();
        }
        return;
    }

    if (files.length === 0 && !['ppt_gen', 'html2pdf'].includes(tool.id)) {
        alert("Please upload a file first.");
        return;
    }

    setStep('processing');
    setProcessing(true);
    setProcessingProgress(0);
    
    const formData = new FormData();
    files.forEach(f => formData.append('files', f));
    if (files.length > 0) formData.append('file', files[0]);
    
    Object.keys(options).forEach(key => formData.append(key, options[key]));

    // Handle Signature blob
    if (tool.id === 'sign' && canvasRef.current) {
         await new Promise<void>(resolve => {
             canvasRef.current?.toBlob(blob => {
                 if(blob) formData.append('signature', blob);
                 resolve();
             });
         });
    }

    const progressInterval = setInterval(() => {
        setProcessingProgress(prev => {
            if (prev >= 95) return 95;
            return prev + 2;
        });
    }, 100);

    try {
      const blob = await processTool(tool.id, formData);
      
      clearInterval(progressInterval);
      setProcessingProgress(100);

      // Consume limit on success
      if (tool.id === 'ppt_gen') incrementTopicLimit();

      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      let ext = 'pdf';
      if (tool.id === 'ppt_gen' || tool.id === 'pdf2ppt') ext = 'pptx';
      if (tool.id === 'pdf2word') ext = 'docx';
      if (tool.id === 'pdf2excel') ext = 'xlsx';
      if (tool.id === 'pdf2jpg') ext = 'zip'; 
      
      a.download = `BuiltTheory_${tool.id}_Result.${ext}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      
      setTimeout(() => setStep('done'), 500);

    } catch (e) {
      clearInterval(progressInterval);
      alert("Error processing file.");
      setStep('config');
    } finally {
      setProcessing(false);
    }
  };

  // --- RENDERERS ---

  const renderStepper = () => {
      const steps = [
          { id: 'upload', label: 'Upload' },
          { id: 'config', label: 'Settings' },
          { id: 'processing', label: 'Process' },
          { id: 'done', label: 'Result' }
      ];
      
      const currentIdx = steps.findIndex(s => s.id === step);

      return (
          <div className="w-full max-w-2xl mb-8">
              <div className="flex justify-between relative">
                  <div className="absolute top-1/2 left-0 w-full h-1 bg-gray-200 -z-10 -translate-y-1/2 rounded-full"></div>
                  <div 
                    className="absolute top-1/2 left-0 h-1 bg-primary -z-10 -translate-y-1/2 rounded-full transition-all duration-500"
                    style={{ width: `${(currentIdx / (steps.length - 1)) * 100}%` }}
                  ></div>

                  {steps.map((s, idx) => {
                      const isActive = idx <= currentIdx;
                      const isCurrent = idx === currentIdx;
                      
                      return (
                          <div key={s.id} className="flex flex-col items-center gap-2 bg-white px-2">
                              <div className={`
                                  w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border-2 transition-all
                                  ${isActive ? 'bg-primary border-primary text-white' : 'bg-white border-gray-300 text-gray-400'}
                              `}>
                                  {isActive ? <i className="fas fa-check"></i> : idx + 1}
                              </div>
                              <span className={`text-xs font-medium ${isCurrent ? 'text-primary' : 'text-gray-400'}`}>
                                  {s.label}
                              </span>
                          </div>
                      );
                  })}
              </div>
          </div>
      );
  };

  const renderUploadStep = () => {
      if (tool.id === 'compare') {
          return (
              <div className="w-full max-w-4xl grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="border-2 border-dashed border-gray-300 rounded-2xl p-8 text-center hover:bg-gray-50 transition cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                      <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4 text-primary text-2xl">1</div>
                      <p className="font-bold text-gray-700">{files[0] ? files[0].name : "Upload File A"}</p>
                  </div>
                  <div className="border-2 border-dashed border-gray-300 rounded-2xl p-8 text-center hover:bg-gray-50 transition cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                      <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-4 text-primary text-2xl">2</div>
                      <p className="font-bold text-gray-700">{files[1] ? files[1].name : "Upload File B"}</p>
                  </div>
                  
                  <div className="md:col-span-2 text-center">
                      <p className="text-sm text-gray-500 mb-4">Upload both versions to compare changes.</p>
                      <button 
                        disabled={files.length < 2}
                        onClick={() => setStep('config')}
                        className={`px-8 py-3 rounded-xl font-bold ${files.length >= 2 ? 'bg-primary text-white' : 'bg-gray-200 text-gray-400'}`}
                      >
                          Proceed to Compare
                      </button>
                  </div>
              </div>
          );
      }

      return (
        <div 
           className={`
               w-full max-w-xl p-12 rounded-2xl border-2 border-dashed transition-all cursor-pointer text-center relative overflow-hidden
               ${isDragging ? 'border-primary bg-red-50' : 'border-gray-300 hover:border-primary hover:bg-white'}
           `}
           onDragOver={handleDragOver}
           onDragLeave={handleDragLeave}
           onDrop={handleDrop}
           onClick={() => !uploadProgress && fileInputRef.current?.click()}
        >
           {uploadProgress > 0 ? (
               <div className="flex flex-col items-center justify-center h-full">
                    <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-6">
                        <span className="text-primary font-bold text-xl">{Math.round(uploadProgress)}%</span>
                    </div>
                    <div className="w-full max-w-[200px] h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div className="h-full bg-primary transition-all duration-100" style={{width: `${uploadProgress}%`}}></div>
                    </div>
                    <p className="mt-4 text-gray-500 font-medium">Uploading...</p>
               </div>
           ) : (
               <>
                    <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-6 text-primary text-3xl">
                        <i className={`fas ${tool.icon}`}></i>
                    </div>
                    <h3 className="text-2xl font-bold text-gray-800 mb-2">Drop files here</h3>
                    <p className="text-gray-500 mb-6">or click to browse</p>
                    <span className="inline-block bg-gray-100 text-gray-600 px-3 py-1 rounded text-xs font-medium">
                        {user?.isPremium ? 'Limit: 10GB' : 'Limit: 50MB'}
                    </span>
               </>
           )}
        </div>
      );
  };

  const renderMergeUI = () => (
    <div className="flex flex-col md:flex-row gap-6 w-full max-w-4xl h-full p-4">
      <div className="w-full md:w-1/3 border border-gray-200 rounded-xl p-4 bg-white flex flex-col">
         <div className="flex justify-between items-center mb-4">
             <h3 className="font-bold text-gray-700">File Order</h3>
             <button 
                onClick={() => {
                    if (!user?.isPremium && files.length >= 10) {
                        if(window.confirm("Upgrade to Pro for unlimited file merging?")) onJoinPro();
                        return;
                    }
                    fileInputRef.current?.click();
                }} 
                className={`text-sm font-bold text-primary`}
            >
                + Add
             </button>
         </div>
         <div className="flex-1 overflow-y-auto space-y-2 pr-2">
            {files.map((f, i) => (
                <div key={i} className="bg-gray-50 p-3 rounded-lg border border-gray-100 flex justify-between items-center group hover:shadow-sm">
                    <div className="flex items-center gap-2 overflow-hidden">
                        <span className="bg-gray-200 text-gray-600 text-xs w-5 h-5 flex items-center justify-center rounded-full">{i+1}</span>
                        <span className="truncate text-sm text-gray-700">{f.name}</span>
                    </div>
                    <button onClick={() => setFiles(files.filter((_, idx) => idx !== i))} className="text-gray-400 hover:text-red-500">
                        <i className="fas fa-times"></i>
                    </button>
                </div>
            ))}
         </div>
         <div className="mt-2 text-center text-xs text-gray-400">
            {files.length}/{user?.isPremium ? '∞' : '10'} files
         </div>
      </div>
      <div className="flex-1 flex flex-col justify-center items-center text-center p-8 bg-gray-50 rounded-xl border border-dashed border-gray-200">
         <i className="fas fa-object-group text-5xl text-gray-300 mb-4"></i>
         <h2 className="text-xl font-bold text-gray-800 mb-2">Merge {files.length} Documents</h2>
         <p className="text-gray-500 text-sm mb-6 max-w-xs">Combine PDF files in the order specified on the left list.</p>
         <button onClick={executeProcess} className="bg-primary text-white px-10 py-3 rounded-xl font-bold shadow-lg hover:bg-red-600 transition-all">
            Merge Files
         </button>
      </div>
    </div>
  );

  const renderSplitUI = () => (
    <div className="w-full max-w-lg">
        <h3 className="text-xl font-bold text-gray-800 mb-6 text-center">Split PDF Options</h3>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 space-y-6">
            <div className="flex gap-4 p-1 bg-gray-100 rounded-lg">
                <button 
                    className={`flex-1 py-2 rounded-md text-sm font-medium transition-all ${options.mode !== 'all' ? 'bg-white shadow text-primary' : 'text-gray-500'}`}
                    onClick={() => setOptions({...options, mode: 'range'})}
                >Extract Pages</button>
                <button 
                    className={`flex-1 py-2 rounded-md text-sm font-medium transition-all ${options.mode === 'all' ? 'bg-white shadow text-primary' : 'text-gray-500'}`}
                    onClick={() => setOptions({...options, mode: 'all'})}
                >Separate All</button>
            </div>

            {options.mode !== 'all' && (
                <div>
                    <label className="block text-sm font-bold text-gray-700 mb-2">Page Ranges</label>
                    <input 
                        type="text" 
                        className="w-full border border-gray-200 rounded-xl p-3 focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                        placeholder="e.g. 1-5, 8, 10"
                        onChange={(e) => setOptions({...options, pages: e.target.value})}
                    />
                    <p className="text-xs text-gray-400 mt-2">Example: Type '1-5' to extract first 5 pages.</p>
                </div>
            )}
            
            <button onClick={executeProcess} className="w-full bg-primary text-white py-3 rounded-xl font-bold hover:bg-red-600 transition-colors">
                Split PDF
            </button>
        </div>
    </div>
  );

  const renderCompressUI = () => (
    <div className="w-full max-w-2xl">
        <div className="text-center mb-8">
            <h3 className="text-xl font-bold text-gray-800">Compress PDF</h3>
            <p className="text-gray-500">Reduce file size while maintaining quality</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            {['low', 'recommended', 'extreme'].map((level) => (
                <div 
                    key={level}
                    onClick={() => setOptions({...options, level})}
                    className={`
                        cursor-pointer border-2 rounded-xl p-4 text-center transition-all
                        ${options.level === level ? 'border-primary bg-red-50' : 'border-gray-100 bg-white hover:border-gray-200'}
                    `}
                >
                    <div className="mb-2 text-primary">
                        <i className={`fas ${level === 'extreme' ? 'fa-compress' : level === 'recommended' ? 'fa-check-circle' : 'fa-image'}`}></i>
                    </div>
                    <div className="font-bold text-gray-800 capitalize">{level}</div>
                    <div className="text-xs text-gray-400 mt-1">
                        {level === 'extreme' ? '-70% size' : level === 'recommended' ? '-40% size' : '-10% size'}
                    </div>
                </div>
            ))}
        </div>
        
        <div className="flex justify-center">
             <button onClick={executeProcess} className="bg-primary text-white px-12 py-3 rounded-xl font-bold hover:scale-105 transition-transform">
                Compress Now
            </button>
        </div>
    </div>
  );

  const renderVisualGridUI = (action: 'rotate' | 'organize' | 'extract') => (
      <div className="w-full h-full flex flex-col">
          <div className="flex justify-between items-center mb-4 px-4">
              <h3 className="font-bold text-lg capitalize">{action} Pages</h3>
              <div className="flex gap-2">
                  <button onClick={() => setMockPages(mockPages.map(p => ({...p, rot: (p.rot + 90) % 360})))} className="text-sm bg-white border border-gray-200 px-3 py-1 rounded hover:bg-gray-50">Rotate All</button>
                  <button onClick={() => setMockPages([])} className="text-sm text-red-500 hover:text-red-700 px-3 py-1">Clear All</button>
              </div>
          </div>
          <div className="flex-1 overflow-y-auto bg-gray-100 rounded-xl p-6 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
               {mockPages.map((page, idx) => (
                   <div key={page.id} className="relative group bg-white rounded shadow-sm hover:shadow-md transition-all aspect-[3/4] flex flex-col items-center justify-center">
                       <div 
                         className="w-full h-full flex items-center justify-center transition-transform duration-300 text-gray-300 font-serif text-4xl select-none"
                         style={{ transform: `rotate(${page.rot}deg)`}}
                       >
                           {page.id}
                       </div>
                       
                       {/* Overlays based on action */}
                       <div className="absolute inset-0 bg-black/5 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                           {action === 'rotate' && (
                               <button onClick={() => {
                                   const newPages = [...mockPages];
                                   newPages[idx].rot = (newPages[idx].rot + 90) % 360;
                                   setMockPages(newPages);
                               }} className="bg-white rounded-full w-8 h-8 text-dark hover:bg-primary hover:text-white shadow-lg"><i className="fas fa-redo"></i></button>
                           )}
                           {(action === 'organize' || action === 'extract') && (
                               <button onClick={() => {
                                   const newPages = mockPages.filter((_, i) => i !== idx);
                                   setMockPages(newPages);
                               }} className="bg-white rounded-full w-8 h-8 text-red-500 hover:bg-red-500 hover:text-white shadow-lg"><i className="fas fa-trash"></i></button>
                           )}
                       </div>
                       <div className="absolute bottom-2 text-xs text-gray-400 font-medium">Page {page.id}</div>
                   </div>
               ))}
               <div className="aspect-[3/4] border-2 border-dashed border-gray-300 rounded flex flex-col items-center justify-center text-gray-400 cursor-pointer hover:border-primary hover:text-primary transition-colors">
                   <i className="fas fa-plus mb-2"></i>
                   <span className="text-xs">Add Blank</span>
               </div>
          </div>
          <div className="mt-4 flex justify-end">
              <button onClick={executeProcess} className="bg-primary text-white px-8 py-3 rounded-xl font-bold shadow-lg">
                  Apply Changes
              </button>
          </div>
      </div>
  );

  const renderSecurityUI = (type: 'protect' | 'unlock') => (
    <div className="max-w-md w-full text-center">
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
            <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className={`fas ${type === 'protect' ? 'fa-lock' : 'fa-key'} text-2xl text-primary`}></i>
            </div>
            <h3 className="text-xl font-bold mb-2">{type === 'protect' ? 'Protect PDF' : 'Unlock PDF'}</h3>
            <p className="text-gray-500 text-sm mb-6">
                {type === 'protect' 
                    ? 'Encrypt your PDF with a password so it cannot be opened by unauthorized users.' 
                    : 'Remove the password security from your PDF file.'}
            </p>
            <input 
                type="password"
                placeholder={type === 'protect' ? "Enter new password" : "Enter current password"}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 mb-4 focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                onChange={(e) => setOptions({...options, password: e.target.value})}
            />
            {type === 'protect' && (
                 <input 
                    type="password"
                    placeholder="Confirm password"
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 mb-4 focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                />
            )}
            <button onClick={executeProcess} className="w-full bg-primary text-white py-3 rounded-xl font-bold hover:bg-red-600 transition-colors">
                {type === 'protect' ? 'Encrypt File' : 'Unlock File'}
            </button>
        </div>
    </div>
  );

  const renderWatermarkUI = () => (
      <div className="w-full max-w-4xl grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-4">
              <h3 className="font-bold text-gray-700">Watermark Text</h3>
              <input type="text" placeholder="e.g. CONFIDENTIAL" className="w-full border p-3 rounded-lg" onChange={(e) => setOptions({...options, text: e.target.value})} />
              
              <h3 className="font-bold text-gray-700">Appearance</h3>
              <div className="grid grid-cols-2 gap-4">
                  <div>
                      <label className="text-xs text-gray-500">Color</label>
                      <input type="color" className="w-full h-10 rounded cursor-pointer" onChange={(e) => setOptions({...options, color: e.target.value})} />
                  </div>
                  <div>
                      <label className="text-xs text-gray-500">Opacity</label>
                      <input type="range" min="0" max="100" className="w-full mt-2" onChange={(e) => setOptions({...options, opacity: e.target.value})} />
                  </div>
              </div>
          </div>
          <div className="bg-gray-100 rounded-xl flex items-center justify-center p-8">
             <div className="bg-white shadow-lg w-48 h-64 relative flex items-center justify-center overflow-hidden">
                 <div className="absolute inset-0 flex items-center justify-center pointer-events-none transform -rotate-45">
                     <span className="text-2xl font-bold text-gray-300 opacity-50 select-none">
                         {options.text || "WATERMARK"}
                     </span>
                 </div>
                 <div className="text-[8px] text-gray-300 p-2 text-justify">
                     Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                 </div>
             </div>
          </div>
          <button onClick={executeProcess} className="col-span-1 md:col-span-2 bg-primary text-white py-3 rounded-xl font-bold">Add Watermark</button>
      </div>
  );

  const renderSignatureUI = () => (
      <div className="w-full max-w-2xl text-center">
          <h3 className="text-xl font-bold mb-4">Draw Your Signature</h3>
          <div className="bg-white border-2 border-dashed border-gray-300 rounded-xl overflow-hidden relative cursor-crosshair touch-none">
              <canvas 
                  ref={canvasRef} 
                  width={600} 
                  height={300} 
                  className="w-full h-64 bg-white"
                  onMouseDown={startDrawing}
                  onMouseMove={draw}
                  onMouseUp={stopDrawing}
                  onMouseLeave={stopDrawing}
              />
              <button onClick={clearSignature} className="absolute top-2 right-2 text-xs bg-gray-100 px-2 py-1 rounded text-gray-500 hover:text-red-500">
                  <i className="fas fa-trash mr-1"></i> Clear
              </button>
          </div>
          <div className="mt-6 flex justify-center gap-4">
              <button onClick={executeProcess} className="bg-primary text-white px-8 py-3 rounded-xl font-bold shadow-lg">
                  Sign Document
              </button>
          </div>
      </div>
  );

  const renderPPTGenUI = () => (
    <div className="w-full max-w-3xl flex flex-col md:flex-row gap-8">
        <div className="flex-1 space-y-6">
             <div>
                <label className="font-bold text-gray-700 block mb-2">Presentation Topic</label>
                <input type="text" className="w-full border border-gray-300 p-3 rounded-xl" placeholder="e.g. Introduction to Thermodynamics" onChange={(e) => setOptions({...options, topic: e.target.value})} />
             </div>
             <div>
                <label className="font-bold text-gray-700 block mb-2">Target Audience</label>
                <select className="w-full border border-gray-300 p-3 rounded-xl bg-white" onChange={(e) => setOptions({...options, audience: e.target.value})}>
                    <option>University Students</option>
                    <option>Professional Engineers</option>
                    <option>General Public</option>
                </select>
             </div>
             <div>
                <label className="font-bold text-gray-700 block mb-2">Slide Count (Approx)</label>
                <input type="number" defaultValue={10} className="w-full border border-gray-300 p-3 rounded-xl" onChange={(e) => setOptions({...options, slides: e.target.value})} />
             </div>
        </div>
        <div className="w-full md:w-1/3 bg-blue-50 p-6 rounded-2xl border border-blue-100">
            <h4 className="font-bold text-blue-900 mb-2">AI Outline</h4>
            <p className="text-sm text-blue-700 mb-4">We will generate:</p>
            <ul className="text-sm text-blue-800 space-y-2 list-disc pl-4">
                <li>Title Slide</li>
                <li>Introduction</li>
                <li>Key Concepts</li>
                <li>Technical Analysis</li>
                <li>Conclusion</li>
            </ul>
            <div className="mt-4 p-2 bg-blue-100 rounded text-xs text-blue-800">
                Limit: {user?.isPremium ? 'Unlimited' : '5/month'}
            </div>
            <button onClick={executeProcess} className="w-full mt-2 bg-blue-600 text-white py-2 rounded-lg font-bold hover:bg-blue-700">Generate PPT</button>
        </div>
    </div>
  );

  const renderHTML2PDF = () => (
      <div className="w-full max-w-lg text-center">
          <div className="w-20 h-20 bg-purple-50 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="fas fa-globe text-3xl text-purple-500"></i>
          </div>
          <h3 className="text-xl font-bold mb-2">Website to PDF</h3>
          <p className="text-gray-500 mb-6">Enter the URL of the webpage you want to capture.</p>
          <div className="flex gap-2">
              <input 
                 type="url" 
                 placeholder="https://example.com" 
                 className="flex-1 border border-gray-300 rounded-xl p-3 focus:ring-2 focus:ring-primary/20 outline-none"
                 onChange={(e) => setOptions({...options, url: e.target.value})}
              />
          </div>
          <button onClick={executeProcess} className="mt-6 w-full bg-primary text-white py-3 rounded-xl font-bold">
              Capture & Convert
          </button>
      </div>
  );

  const renderSimpleConvert = (fromIcon: string, toIcon: string, title: string) => (
      <div className="text-center p-8 w-full max-w-lg bg-white rounded-2xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-center gap-6 mb-8">
              <div className="flex flex-col items-center">
                  <i className={`fas ${fromIcon} text-4xl text-gray-400 mb-2`}></i>
                  <span className="text-xs font-bold text-gray-500">{title.split(' ')[0]}</span>
              </div>
              <i className="fas fa-arrow-right text-gray-300 animate-pulse"></i>
              <div className="flex flex-col items-center">
                  <i className={`fas ${toIcon} text-4xl text-primary mb-2`}></i>
                  <span className="text-xs font-bold text-primary">{title.split(' ')[2]}</span>
              </div>
          </div>
          <h3 className="text-lg font-bold mb-2">Convert {files[0]?.name}</h3>
          
          {tool.id === 'ocr' && (
              <div className="mb-4 text-left">
                  <label className="text-xs font-bold text-gray-500 uppercase">Document Language</label>
                  <select className="w-full mt-1 border p-2 rounded-lg" onChange={(e) => setOptions({...options, lang: e.target.value})}>
                      <option value="eng">English</option>
                      <option value="spa">Spanish</option>
                      <option value="deu">German</option>
                      <option value="fra">French</option>
                  </select>
              </div>
          )}
          
          <button onClick={executeProcess} className="w-full bg-primary text-white py-3 rounded-xl font-bold shadow-lg hover:bg-red-600 transition-all">
              Start Conversion
          </button>
      </div>
  );

  const renderConfig = () => {
    switch (tool.id) {
        case 'merge': return renderMergeUI();
        case 'split': return renderSplitUI();
        case 'compress': return renderCompressUI();
        case 'rotate': return renderVisualGridUI('rotate');
        case 'organize': return renderVisualGridUI('organize');
        case 'extract': return renderVisualGridUI('extract');
        case 'protect': return renderSecurityUI('protect');
        case 'unlock': return renderSecurityUI('unlock');
        case 'watermark': return renderWatermarkUI();
        case 'sign': return renderSignatureUI();
        case 'ppt_gen': return renderPPTGenUI();
        case 'html2pdf': return renderHTML2PDF();
        
        // Converters
        case 'img2pdf': return renderSimpleConvert('fa-image', 'fa-file-pdf', 'JPG to PDF');
        case 'pdf2jpg': return renderSimpleConvert('fa-file-pdf', 'fa-image', 'PDF to JPG');
        case 'word2pdf': return renderSimpleConvert('fa-file-word', 'fa-file-pdf', 'Word to PDF');
        case 'pdf2word': return renderSimpleConvert('fa-file-pdf', 'fa-file-word', 'PDF to Word');
        case 'excel2pdf': return renderSimpleConvert('fa-file-excel', 'fa-file-pdf', 'Excel to PDF');
        case 'pdf2excel': return renderSimpleConvert('fa-file-pdf', 'fa-file-excel', 'PDF to Excel');
        case 'ppt2pdf': return renderSimpleConvert('fa-file-powerpoint', 'fa-file-pdf', 'PPT to PDF');
        case 'pdf2ppt': return renderSimpleConvert('fa-file-pdf', 'fa-file-powerpoint', 'PDF to PPT');
        case 'pdf2pdfa': return renderSimpleConvert('fa-file-pdf', 'fa-archive', 'PDF to PDF/A');
        
        case 'ocr': return renderSimpleConvert('fa-file-alt', 'fa-file-alt', 'PDF to Searchable PDF');
        case 'repair': return renderSimpleConvert('fa-file-medical-alt', 'fa-file-pdf', 'Repair PDF');
        case 'compare': return (
            <div className="text-center max-w-lg">
                <i className="fas fa-not-equal text-4xl text-gray-300 mb-4"></i>
                <h3 className="font-bold text-lg mb-2">Ready to Compare</h3>
                <p className="text-gray-500 mb-6">We will highlight text and visual differences between {files[0].name} and {files[1].name}.</p>
                <button onClick={executeProcess} className="bg-primary text-white px-8 py-3 rounded-xl font-bold">Compare Files</button>
            </div>
        );

        default: return (
             <div className="text-center p-8">
                 <p className="mb-4">Standard processing for {tool.title}</p>
                 <button onClick={executeProcess} className="bg-primary text-white px-8 py-2 rounded-lg">Process</button>
             </div>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-900/60 backdrop-blur-sm p-4">
      <div className="bg-white rounded-3xl w-full max-w-6xl h-[90vh] flex flex-col shadow-2xl overflow-hidden relative animate-[fadeIn_0.2s_ease-out]">
        
        {/* Workspace Header */}
        <div className="flex justify-between items-center px-8 py-5 border-b border-gray-100 bg-white z-10">
            <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-red-50 rounded-xl flex items-center justify-center text-primary text-xl shadow-inner">
                    <i className={`fas ${tool.icon}`}></i>
                </div>
                <div>
                    <h2 className="font-extrabold text-xl text-gray-800 tracking-tight">{tool.title}</h2>
                    <p className="text-xs text-gray-400 font-medium tracking-wide uppercase">Built-Theory Engine</p>
                </div>
            </div>
            <button onClick={onClose} className="w-10 h-10 rounded-full hover:bg-gray-100 flex items-center justify-center text-gray-400 hover:text-gray-800 transition-all">
                <i className="fas fa-times text-xl"></i>
            </button>
        </div>

        {/* Workspace Body */}
        <div className="flex-1 overflow-auto bg-[#f8f9fa] relative flex flex-col items-center p-6">
            
            {/* Stepper */}
            {step !== 'done' && renderStepper()}

            <div className="flex-1 w-full flex items-center justify-center">
                {step === 'upload' && renderUploadStep()}

                {step === 'config' && renderConfig()}

                {step === 'processing' && (
                    <div className="text-center p-12 bg-white rounded-2xl shadow-sm border border-gray-100 w-full max-w-lg">
                        <div className="mb-6 mx-auto">
                            <div className="flex justify-between text-xs font-bold text-gray-500 mb-2">
                                <span>Processing</span>
                                <span>{Math.round(processingProgress)}%</span>
                            </div>
                            <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden">
                                <div 
                                    className="h-full bg-gradient-to-r from-primary to-red-400 transition-all duration-300 relative"
                                    style={{width: `${processingProgress}%`}}
                                >
                                    <div className="absolute inset-0 bg-white/20 animate-[pulse_1s_infinite]"></div>
                                </div>
                            </div>
                        </div>
                        <h3 className="text-2xl font-bold text-gray-800 mb-2">Analyzing Document...</h3>
                        <p className="text-gray-500 animate-pulse text-sm">Please wait while our AI engine processes your request.</p>
                    </div>
                )}

                {step === 'done' && (
                    <div className="text-center animate-[scaleIn_0.3s_ease-out] bg-white p-12 rounded-3xl shadow-xl border border-gray-100 max-w-md">
                        <div className="w-24 h-24 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-6 text-green-500 text-4xl shadow-inner">
                            <i className="fas fa-check"></i>
                        </div>
                        <h3 className="text-2xl font-bold text-gray-800 mb-2">Task Complete!</h3>
                        <p className="text-gray-500 mb-8">Your {tool.title} result is ready.</p>
                        <div className="flex flex-col gap-3">
                            <button className="bg-primary text-white px-8 py-3 rounded-xl font-bold shadow-lg shadow-red-200 hover:bg-red-600 transition-all transform hover:-translate-y-1">
                                <i className="fas fa-download mr-2"></i> Download Again
                            </button>
                            <button onClick={() => { setStep('upload'); setFiles([]); setOptions({}); setUploadProgress(0); setProcessingProgress(0); }} className="text-gray-500 font-medium hover:text-dark py-2">
                                Process Another File
                            </button>
                        </div>
                    </div>
                )}
            </div>
            
            {/* Persistent Hidden Input */}
            <input 
                type="file" 
                multiple 
                className="hidden" 
                ref={fileInputRef} 
                onChange={handleFileSelect}
                accept={getAcceptType()} 
            />

        </div>
      </div>
    </div>
  );
};

export default Workspace;